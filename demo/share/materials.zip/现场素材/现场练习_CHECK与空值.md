# CHECK 与 NOT NULL：把“合法”拆成两个问题

这份课堂练习节选并整理自《数据库系统原理实验笔记：用户定义的完整性与 CHECK 约束》，补充了空值边界；以下语句已经用本机 SQLite 验证。

## 业务目标

选课成绩必须已填写，而且是 0 到 100 之间的整数。在数据库中，“必须填写”与“数值范围正确”是两条不同的约束。

```sql
CREATE TABLE grade_demo (
  student_id TEXT PRIMARY KEY,
  grade INTEGER NOT NULL
    CHECK (typeof(grade) = 'integer' AND grade BETWEEN 0 AND 100)
);
```

这里的 `typeof` 是 SQLite 函数，其他数据库需要按自己的类型规则表达整数约束。

| 输入成绩 | 预期结果 | 对应规则 |
| --- | --- | --- |
| 0、60、100 | 接受 | 合法整数及边界 |
| -1、101 | 拒绝 | 超出区间 |
| NULL | 拒绝 | NOT NULL |
| 60.5 | 拒绝 | 必须是整数 |

## 容易忽略的边界

如果仅写 `CHECK (grade BETWEEN 0 AND 100)`，NULL 不会使检查表达式为 false，在 SQLite 中仍可以通过。因此不能用 CHECK 代替 NOT NULL。

记忆方法：先问“能否缺失”，再问“出现后是否合法”。设计测试时，成功用例和失败用例都要覆盖，并核对失败后没有留下部分写入。
